db_user = 'root'  # (MySql username)
db_pass = 'root'  # (MySql password)
