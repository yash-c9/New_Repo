from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os

class OverwriteStorage(FileSystemStorage):

    def get_available_name(self, name):

        if self.exists(name):
            print name
            os.remove(name)
        return name
