from django.test import TestCase
from django.test.client import Client
from models import NotificationEmail
from website.models import Question, Answer, Notification, \
    AnswerComment, FossCategory, Profile, SubFossCategory, FossCategory
from moderator import views
from django.contrib.auth.models import User
import datetime
from django.contrib.auth.models import AnonymousUser, User
from django.test import TestCase, RequestFactory
from moderator import views
from moderator.util import delete_question_util, delete_answer_util,\
    delete_comment_util


# test for deleting question and all the annswers and commments along with it

class DeleteQuestion(TestCase):

    def test_delete_question(self):
        user = User(id=1, username='abcd')
        user.save()
        category = FossCategory(id=1, name='Genius',
                                date_created=datetime.datetime.now())
        category.save()
        question = Question(
            id=1,
            category_id=1,
            title='What is it',
            body='What now',
            views=1,
            user_id=1,
            date_created=datetime.datetime.now(),
            )
        question.save()
        qid = question.id
        answer = Answer(id=1, uid=1, body='nice answer', question_id=1,
                        date_created=datetime.datetime.now())
        answer.save()
        aid = answer.id
        answercomment = AnswerComment(id=1, uid=1, body='nice comment',
                answer_id=1, date_created=datetime.datetime.now())

        answercomment.save()

        views.delete_question_util(qid)
        self.assertIs(Question.objects.filter(id=qid).exists(), False)
        self.assertIs(Answer.objects.filter(question_id=qid).exists(),
                      False)
        self.assertIs(AnswerComment.objects.filter(answer_id=aid).exists(),
                      False)


# test for user updatation
class UserUpdate(TestCase):

    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(id=2, username='jacob',
                email='jacob@gmail.com', is_active=True, is_staff=True)
        user = User(id=1, username='abcd', is_staff=True,
                    is_active=True)

        user.save()
        self.user_id = user.id


    def test_user_update(self):
        request = self.factory.post('/moderator/user/user_update/',
                                    {u'Remove from Staff': [u'Remove from Staff'
                                    ], u'User_id': [u'1'],
                                    u'myTable_length': [u'10']})

        request.user = self.user

        response = views.user_update(request)
        self.assertEqual(response.status_code, 302)
        self.assertIs(User.objects.get(id=self.user_id).is_staff, False)

        request = self.factory.post('/moderator/user/user_update/',
                                    {u'Add in Staff': [u'Add in Staff'
                                    ], u'User_id': [self.user_id],
                                    u'myTable_length': [u'10']})
        request.user = self.user

        response = views.user_update(request)
        self.assertEqual(response.status_code, 302)
        self.assertIs(User.objects.get(id=self.user_id).is_staff, True)

        # activating and deactivating user
        request = self.factory.post('/moderator/user/user_update/',
                                    {u'Deactivate': [u'Deactivate'],
                                    u'User_id': [self.user_id],
                                    u'myTable_length': [u'10']})
        request.user = self.user
        response = views.user_update(request)
        self.assertEqual(response.status_code, 302)
        self.assertIs(User.objects.get(id=self.user_id).is_active, False)

        request = self.factory.post('/moderator/user/user_update/',
                                    {u'Activate': [u'Activate'],
                                    u'User_id': [self.user_id],
                                    u'myTable_length': [u'10']})
        request.user = self.user
        response = views.user_update(request)
        self.assertEqual(response.status_code, 302)
        self.assertIs(User.objects.get(id=self.user_id).is_active, True)
        user_id1 = self.user.id

        # boundary case when user logged in should not be able to remove
        request = self.factory.post('/moderator/user/user_update/',
                                    {u'Remove from Staff': [u'Remove from Staff'
                                    ], u'User_id': [self.user_id, user_id1],
                                    u'myTable_length': [u'10']})

        request.user = self.user

        response = views.user_update(request)
        self.assertEqual(response.status_code, 302)
        self.assertIs(User.objects.get(id=self.user_id).is_staff, False)
        self.assertIs(User.objects.get(id=user_id1).is_staff, True)


# test for index page to load correctly
class HomePage(TestCase):

    def setUp(self):

        self.factory = RequestFactory()
        self.user = User.objects.create_user(id=2, username='jacob',
                email='jacob@gmail.com', is_active=True, is_staff=True)

    def test_home_page(self):

        request = self.factory.get('/moderator/')
        request.user = self.user

        response = views.home(request)
        self.assertEqual(response.status_code, 200)  # successful rendering


# delete question through get request
class DeleteQuestionWeb(TestCase):

    def setUp(self):

        # Every test needs access to the request factory.

        self.factory = RequestFactory()
        self.user1 = User.objects.create_user(id=2, username='jacob',
                email='jacob@gmail.com', is_active=True, is_staff=True)
        user = User(id=1, username='abcd')
        user.save()
        category = FossCategory(id=1, name='Genius',
                                date_created=datetime.datetime.now())
        category.save()
        question = Question(
            id=1,
            category_id=1,
            title='What is it',
            body='What now',
            views=1,
            user_id=1,
            date_created=datetime.datetime.now(),
            )
        question.save()
        self.qid = question.id
        answer = Answer(id=1, uid=1, body='nice answer', question_id=1,
                        date_created=datetime.datetime.now())
        answer.save()
        self.aid = answer.id
        answercomment = AnswerComment(id=1, uid=1, body='nice comment',
                answer_id=1, date_created=datetime.datetime.now())

        answercomment.save()

    def test_delete_question(self):

        request = self.factory.post('/moderator/user/questions/',
                                    {u'Question_id': [self.qid],
                                    u'myTable_length': [u'10']})
        request.user = self.user1

        response = views.delete_question(request)
        self.assertEqual(response.status_code, 302)

        self.assertIs(Question.objects.filter(id=self.qid).exists(), False)
        self.assertIs(Answer.objects.filter(question_id=self.qid).exists(),
                      False)
        self.assertIs(AnswerComment.objects.filter(answer_id=self.aid).exists(),
                      False)


class CategoryTest(TestCase):

    def setUp(self):

        # Every test needs access to the request factory.

        self.factory = RequestFactory()
        self.user = User.objects.create_user(id=2, username='jacob',
                email='jacob@gmail.com', is_active=True, is_staff=True)

    def test_category_change(self):
        category = FossCategory(id=1, name='Genius',
                                description='Genius',
                                date_created=datetime.datetime.now(),
                                email='genius@gmail.com')
        category.save()
        request = self.factory.post('/moderator/category/'
                                    + str(category.id), {
            u'default_tags': [u'html, java'],
            u'email': [u'genius@gmail.com'],
            u'name': [u'Genius'],
            u'description': [u'Genius1'],
            })

        request.user = self.user

        response = views.category_form(request, category.id)
        self.assertEqual(response.status_code, 302)
